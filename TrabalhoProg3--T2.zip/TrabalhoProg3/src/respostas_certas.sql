-- respostas_certas.sql
CREATE TABLE respostas_certas (
  id INTEGER PRIMARY KEY,
  pergunta_id INTEGER NOT NULL,
  resposta TEXT NOT NULL,
  FOREIGN KEY(pergunta_id) REFERENCES perguntas(id)
);

INSERT INTO respostas_certas (id, pergunta_id, resposta) VALUES
(1, 1, 'O Ashen One (O Peregrino das Cinzas)'),
(2, 2, 'Reunir os Lordes das Cinzas e retornar seus tronos ao Santuário do Elo de Fogo'),
(3, 3, 'Ludleth de Courland, Aldrich, Yhorm o Gigante, os Vigilantes do Abismo e o Príncipe Lothric'),
(4, 4, 'Ela ajuda o jogador a aumentar seus atributos usando almas e representa a chama que mantém o mundo'),
(5, 5, 'Um dos Lordes das Cinzas que permanece voluntariamente em seu trono'),
(6, 6, 'Um clérigo canibal que se tornou um devorador de deuses'),
(7, 7, 'O ciclo de vida, morte e renascimento do mundo, simbolizando a ordem e o caos'),
(8, 8, 'Refere-se à alma sombria herdada pelos humanos, ligada à escuridão e ao ciclo da chama'),

(9, 9, 'Iudex Gundyr'),
(10, 10, 'Vordt do Vale Boreal'),
(11, 11, 'Os Vigilantes do Abismo'),
(12, 12, 'Aldrich, Devourer of Gods'),
(13, 13, 'Alma das Cinzas (Soul of Cinder)'),
(14, 14, 'Sábio de Cristal'),
(15, 15, 'Dançarina do Vale Boreal'),
(16, 16, 'Príncipe Lothric e seu irmão Lorian'),

(17, 17, 'Cemitério das Cinzas'),
(18, 18, 'Logo após derrotar o Iudex Gundyr'),
(19, 19, 'Lago Ardente (Smouldering Lake)'),
(20, 20, 'Catedral das Profundezas'),
(21, 21, 'Castelo de Lothric'),
(22, 22, 'Pico do Arquidragão'),
(23, 23, 'Pico do Arquidragão'),
(24, 24, 'Na parte final do Castelo de Lothric'),

(25, 25, 'Pontos de Foco (FP)'),
(26, 26, 'Recupera vida, recarrega frascos e revive inimigos normais'),
(27, 27, 'Fragmento de Osso de Morto'),
(28, 28, 'Fragmento de Estus'),
(29, 29, 'Usando sinais de invocação e estando com a brasa ativa'),
(30, 30, 'Perde todas as almas acumuladas e volta para a última fogueira'),
(31, 31, 'Invasão'),
(32, 32, 'Titanita Grande (e formas superiores como Titanita Brilhante)'),

(33, 33, 'Frasco de Estus'),
(34, 34, 'Espada Enferrujada do Cemitério'),
(35, 35, 'Anel da Redenção de Lloyd'),
(36, 36, 'Lâminas da Dançarina'),
(37, 37, 'Acendendo a chama após derrotar o chefe final'),
(38, 38, 'Símbolos dos Pactos'),
(39, 39, 'Anel do Havel'),
(40, 40, 'Fornalha de Transposição');
