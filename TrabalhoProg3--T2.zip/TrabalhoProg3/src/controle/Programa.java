package controle;
import view.Janela;
import view.Mapa;


public class Programa {

	public static void main(String[] args) {
		Mapa mapa = new Mapa();
		mapa.setVisible(true);
		
//		Janela j = new Janela();
//		j.setVisible(false);
//		
		Janela j = new Janela(false);  // passa 'false' se quer rádio, 'true' se quer texto+imagem
		j.setVisible(false);

	}
}

