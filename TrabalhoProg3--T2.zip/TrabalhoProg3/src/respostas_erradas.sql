-- respostas_erradas.sql
CREATE TABLE respostas_erradas (
  id INTEGER PRIMARY KEY,
  pergunta_id INTEGER NOT NULL,
  resposta TEXT NOT NULL,
  FOREIGN KEY(pergunta_id) REFERENCES perguntas(id)
);

INSERT INTO respostas_erradas (id, pergunta_id, resposta) VALUES
-- Question 1
(1,  1, 'O Escolhido dos Mortos-Vivos'),
(2,  1, 'O Portador da Maldição'),
(3,  1, 'O Guardião da Alma'),

-- Question 2
(4,  2, 'Derrotar o Rei Sem Nome'),
(5,  2, 'Destruir a chama eterna'),
(6,  2, 'Salvar o mundo da escuridão'),

-- Question 3
(7,  3, 'Gwyn, Artorias e Solaire'),
(8,  3, 'Os oito filhos de Manus'),
(9,  3, 'Os quatro cavaleiros do Apocalipse'),

-- Question 4
(10, 4, 'Concede armas mágicas'),
(11, 4, 'Transforma almas em itens'),
(12, 4, 'Inicia invasões de outros jogadores'),

-- Question 5
(13, 5, 'Um caçador de dragões'),
(14, 5, 'O primeiro chefe opcional'),
(15, 5, 'Um cavaleiro da Irmandade dos Caídos'),

-- Question 6
(16, 6, 'Um ferreiro real'),
(17, 6, 'Um monge silvestre'),
(18, 6, 'Um caçador de dragões'),

-- Question 7
(19, 7, 'A corrupção do abismo'),
(20, 7, 'A invasão de outros jogadores'),
(21, 7, 'A escuridão eterna'),

-- Question 8
(22, 8, 'Significa as almas dos dragões'),
(23, 8, 'Refere-se aos espólios de guerra'),
(24, 8, 'Significa a chama negra do abismo'),

-- Question 9
(25, 9, 'Pontífice Sulyvahn'),
(26, 9, 'Dragão Selvagem de Farron'),
(27, 9, 'Lothric, Príncipe Rejeitado'),

-- Question 10
(28, 10, 'Sábio de Cristal'),
(29, 10, 'Rochoso do Smouldering Lake'),
(30, 10, 'Oceiros, o Rei Desesperado'),

-- Question 11
(31, 11, 'Os Irmãos Lothric'),
(32, 11, 'Os Caçadores do Arena de Pontífice'),
(33, 11, 'Os Cavaleiros de Catarina'),

-- Question 12
(34, 12, 'Yhorm o Gigante'),
(35, 12, 'Ludleth de Courland'),
(36, 12, 'Sulyvahn, o Julgador'),

-- Question 13
(37, 13, 'Fury of the Fire Goddess'),
(38, 13, 'Pontífice Sulyvahn'),
(39, 13, 'O Rei Sem Nome'),

-- Question 14
(40, 14, 'Irmãos Pilgrim'),
(41, 14, 'Soldado do Caminho Real'),
(42, 14, 'Cavaleiro do Abismo'),

-- Question 15
(43, 15, 'A Deusa do Caos'),
(44, 15, 'O Cavaleiro de Astora'),
(45, 15, 'A Dama de Profundezas'),

-- Question 16
(46, 16, 'Os Vigilantes do Abismo'),
(47, 16, 'O Rei Sem Nome'),
(48, 16, 'O Pontífice Sulyvahn'),

-- Question 17
(49, 17, 'Santuário do Elo de Fogo'),
(50, 17, 'Castelo de Lothric'),
(51, 17, 'Lago Ardente'),

-- Question 18
(52, 18, 'Ao entrar no Castelo de Lothric'),
(53, 18, 'Dentro da Catedral das Profundezas'),
(54, 18, 'Na Torre das Gárgulas'),

-- Question 19
(55, 19, 'Pântano de Caos'),
(56, 19, 'Abismo Profundo'),
(57, 19, 'Fortaleza de Farron'),

-- Question 20
(58, 20, 'Vila de Farron'),
(59, 20, 'Fortaleza de Lothric'),
(60, 20, 'Vale Boreal'),

-- Question 21
(61, 21, 'Fortaleza de Carthus'),
(62, 21, 'Torre do Arquimago'),
(63, 21, 'Castelo de Drangleic'),

-- Question 22
(64, 22, 'Lago Ardente'),
(65, 22, 'Cemitério das Cinzas'),
(66, 22, 'Santuário do Elo de Fogo'),

-- Question 23
(67, 23, 'Tumba dos Gigantes'),
(68, 23, 'Memória de Artorias'),
(69, 23, 'Gruta Abissal'),

-- Question 24
(70, 24, 'No topo do Pico do Arquidragão'),
(71, 24, 'Dentro da Catedral das Profundezas'),
(72, 24, 'Perto do Lago Ardente'),

-- Question 25
(73, 25, 'Pontos de Alma (AP)'),
(74, 25, 'Pontos de Espírito (SP)'),
(75, 25, 'Pontos de Mana (MP)'),

-- Question 26
(76, 26, 'Reinicia a posição dos chefes'),
(77, 26, 'Aumenta permanentemente os atributos'),
(78, 26, 'Limpa o inventário'),

-- Question 27
(79, 27, 'Megafragmento de Titanita'),
(80, 27, 'Pedra de Fogo'),
(81, 27, 'Pedra de Almas'),

-- Question 28
(82, 28, 'Alma de Estus'),
(83, 28, 'Caco de Chama'),
(84, 28, 'Cristal de Fogo'),

-- Question 29
(85, 29, 'Usando Orbs de Caos'),
(86, 29, 'Invocando NPCs no menu'),
(87, 29, 'Pagando Silver Knights'),

-- Question 30
(88, 30, 'Reseta todos os níveis de armadura'),
(89, 30, 'Troca de classe automaticamente'),
(90, 30, 'Desativa online por 5 minutos'),

-- Question 31
(91, 31, 'Cooperação'),
(92, 31, 'Duelo'),
(93, 31, 'JcJ gratuito'),

-- Question 32
(94, 32, 'Fragmento de Estus'),
(95, 32, 'Cristal Primordial'),
(96, 32, 'Artifact of Power'),

-- Question 33
(97, 33, 'Frasco de Cinzas'),
(98, 33, 'Frasco de Alma'),
(99, 33, 'Frasco de Chama'),

-- Question 34
(100,34, 'Martelo Lendário'),
(101,34, 'Foice da Catedral'),
(102,34, 'Espada Longa de Lothric'),

-- Question 35
(103,35, 'Anel da Fênix'),
(104,35, 'Anel do Lobo'),
(105,35, 'Anel do Caos'),

-- Question 36
(106,36, 'Lança de Lothric'),
(107,36, 'Martelo do Gigante'),
(108,36, 'Espada de Cristal'),

-- Question 37
(109,37, 'Pedra do Infinito'),
(110,37, 'Anel da Renascença'),
(111,37, 'Tabuleiro do Tempo'),

-- Question 38
(112,38, 'Marca de Brasa'),
(113,38, 'Emblema Real'),
(114,38, 'Pedra de Transposição'),

-- Question 39
(115,39, 'Anel de Lothric'),
(116,39, 'Anel de Silver Knight'),
(117,39, 'Anel da Resistência'),

-- Question 40
(118,40, 'Chave do Covil'),
(119,40, 'Pedra de Transposição'),
(120,40, 'Cajado das Cinzas');
    