-- perguntas.sql
CREATE TABLE perguntas (
  id INTEGER PRIMARY KEY,
  categoria TEXT NOT NULL,
  texto TEXT NOT NULL
);

INSERT INTO perguntas (id, categoria, texto) VALUES
(1, 'Lore e História', 'Quem é o protagonista de Dark Souls III?'),
(2, 'Lore e História', 'Qual é o objetivo principal do protagonista no jogo?'),
(3, 'Lore e História', 'Quem são os Lordes das Cinzas em Dark Souls III?'),
(4, 'Lore e História', 'Qual é o papel da Guardiã do Fogo?'),
(5, 'Lore e História', 'Quem é Ludleth de Courland?'),
(6, 'Lore e História', 'Quem foi Aldrich antes de se tornar um Lorde das Cinzas?'),
(7, 'Lore e História', 'O que representa a chama em Dark Souls III?'),
(8, 'Lore e História', 'Qual o significado do título "Dark Souls"?'),

(9, 'Chefes e Inimigos', 'Qual é o primeiro chefe obrigatório do jogo?'),
(10, 'Chefes e Inimigos', 'Qual chefe se transforma durante a luta e representa a corrupção do abismo?'),
(11, 'Chefes e Inimigos', 'Qual chefe é uma fusão de vários guerreiros em uma luta de grupo?'),
(12, 'Chefes e Inimigos', 'Qual chefe é conhecido por devorar deuses e usa ataques mágicos?'),
(13, 'Chefes e Inimigos', 'Quem é o chefe final do jogo base?'),
(14, 'Chefes e Inimigos', 'Qual chefe se divide em múltiplas cópias ilusórias durante a luta?'),
(15, 'Chefes e Inimigos', 'Qual chefe opcional aparece em uma catedral e usa ataques com espada curva?'),
(16, 'Chefes e Inimigos', 'Quem é o chefe encontrado no topo do Grande Arquivo?'),

(17, 'Locais e Áreas', 'Qual é a área inicial do jogo?'),
(18, 'Locais e Áreas', 'Onde o jogador encontra o Santuário do Elo de Fogo?'),
(19, 'Locais e Áreas', 'Qual área está infestada por tóxicos e é semelhante ao Pântano de Blighttown?'),
(20, 'Locais e Áreas', 'Qual cidade está associada ao culto dos deuses e à Aldrich?'),
(21, 'Locais e Áreas', 'Qual é o castelo de Lothric chamado?'),
(22, 'Locais e Áreas', 'Em que área o jogador enfrenta o Rei Sem Nome?'),
(23, 'Locais e Áreas', 'Qual área secreta é acessada por meio do gesto do dragão?'),
(24, 'Locais e Áreas', 'Onde se localiza o Grande Arquivo?'),

(25, 'Mecânicas e Jogabilidade', 'Como se chama o sistema de pontos usado para conjurar feitiços e habilidades de arma?'),
(26, 'Mecânicas e Jogabilidade', 'O que acontece quando o jogador descansa em uma fogueira?'),
(27, 'Mecânicas e Jogabilidade', 'Qual item é usado para aumentar a cura dos frascos de Estus?'),
(28, 'Mecânicas e Jogabilidade', 'Qual item aumenta a quantidade de usos dos frascos de Estus?'),
(29, 'Mecânicas e Jogabilidade', 'Como o jogador pode invocar ajuda para lutas contra chefes?'),
(30, 'Mecânicas e Jogabilidade', 'Qual penalidade o jogador sofre ao morrer?'),
(31, 'Mecânicas e Jogabilidade', 'Como é chamado o modo online competitivo onde jogadores invadem o mundo de outros?'),
(32, 'Mecânicas e Jogabilidade', 'O que é necessário para melhorar armas além do +5?'),

(33, 'Itens e Equipamentos', 'Qual é o principal item de cura do jogo?'),
(34, 'Itens e Equipamentos', 'Que tipo de arma o jogador recebe após derrotar o Iudex Gundyr?'),
(35, 'Itens e Equipamentos', 'Qual item permite aumentar atributos temporariamente em troca de vida?'),
(36, 'Itens e Equipamentos', 'Qual arma pode ser obtida ao transpor a alma da Dançarina do Vale Boreal?'),
(37, 'Itens e Equipamentos', 'Qual é o nome do item usado para entrar em New Game Plus?'),
(38, 'Itens e Equipamentos', 'Qual item mostra o caminho dos pactos e convenções online?'),
(39, 'Itens e Equipamentos', 'Qual é o anel que aumenta a carga de equipamento?'),
(40, 'Itens e Equipamentos', 'Qual é o item necessário para realizar transposição de almas de chefe?');
