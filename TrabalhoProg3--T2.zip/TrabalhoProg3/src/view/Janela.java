package view;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.*;
import java.util.*;

public class Janela extends JFrame {
    private JPanel contentPane;
    private JLabel perguntaLabel;
    private JRadioButton[] opcoes;
    private ButtonGroup grupo;
    private JButton enviarButton;
    private Connection con;

    public Janela() {
        super("Pergunta");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(600, 250);
        setLocationRelativeTo(null);

        contentPane = new JPanel(new BorderLayout(10, 10));
        setContentPane(contentPane);

        conectar();
        Pergunta p = carregarPerguntaAleatoria();

//        perguntaLabel = new JLabel(p.texto);
        perguntaLabel = new JLabel("<html><body style='width:350px;'>" 
        	    + p.texto
        	    + "</body></html>");
        perguntaLabel.setFont(perguntaLabel.getFont().deriveFont(24f));
        contentPane.add(perguntaLabel, BorderLayout.NORTH);

        grupo = new ButtonGroup();
        opcoes = new JRadioButton[4];
        JPanel painel = new JPanel(new GridLayout(4, 1));
        for (int i = 0; i < 4; i++) {
            opcoes[i] = new JRadioButton(p.opcoes[i]);
            grupo.add(opcoes[i]);
            painel.add(opcoes[i]);
        }
        contentPane.add(painel, BorderLayout.CENTER);

        enviarButton = new JButton("Enviar");
        enviarButton.addActionListener(e -> {
            for (JRadioButton rb : opcoes) {
                if (rb.isSelected()) {
                    String msg = rb.getText().equals(p.correta) ? "Correto!" : "Errado!";

                    
                    JOptionPane.showMessageDialog(this, msg);
                    break;
                }
            }
            dispose();
        });
        contentPane.add(enviarButton, BorderLayout.SOUTH);
    }

    private void conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/perguntas?useSSL=false&serverTimezone=UTC",
                "root", ""
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Pergunta carregarPerguntaAleatoria() {
        Pergunta p = new Pergunta();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, texto FROM perguntas ORDER BY RAND() LIMIT 1")) {
            if (rs.next()) {
                int id = rs.getInt("id");
                p.texto = rs.getString("texto");

                try (PreparedStatement pc = con.prepareStatement(
                         "SELECT resposta FROM respostas_certas WHERE pergunta_id = ?"
                     )) {
                    pc.setInt(1, id);
                    try (ResultSet rcor = pc.executeQuery()) {
                        if (rcor.next()) p.correta = rcor.getString("resposta");
                    }
                }

                List<String> lista = new ArrayList<>();
                lista.add(p.correta);
                try (PreparedStatement pe = con.prepareStatement(
                         "SELECT resposta FROM respostas_erradas WHERE pergunta_id = ? ORDER BY RAND() LIMIT 3"
                     )) {
                    pe.setInt(1, id);
                    try (ResultSet rer = pe.executeQuery()) {
                        while (rer.next()) lista.add(rer.getString("resposta"));
                    }
                }

                Collections.shuffle(lista);
                p.opcoes = lista.toArray(new String[0]);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }

    private static class Pergunta {
        String texto;
        String correta;
        String[] opcoes;
    }
}
