package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class Mapa extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private int personagem = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mapa frame = new Mapa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Mapa() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1700, 940);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		

		
		//BOTOES PERSONAGENS ___________________________________________________________________________________________________________________________________________________________________________
		JButton btnCharacterButton = new JButton("");
		btnCharacterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				personagem = 1;
			}
		});
		btnCharacterButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
		btnCharacterButton.setBounds(18, 50, 40, 42);
		contentPane.add(btnCharacterButton);	
		
		JButton btnCharacterButton2 = new JButton("");
		btnCharacterButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				personagem = 2;
			}
		});
		btnCharacterButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
		btnCharacterButton2.setBounds(62, 50, 40, 42);
		contentPane.add(btnCharacterButton2);
		
		JButton btnCharacterButton3 = new JButton("");
		btnCharacterButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				personagem = 3;
			}
		});
		btnCharacterButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
		btnCharacterButton3.setBounds(105, 50, 40, 42);
		contentPane.add(btnCharacterButton3);
		
		JButton btnCharacterButton4 = new JButton("");
		btnCharacterButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				personagem = 4;
			}
		});
		btnCharacterButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
		btnCharacterButton4.setBounds(148, 50, 40, 42);
		contentPane.add(btnCharacterButton4);
		
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				personagem = 0;
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setBounds(191, 50, 40, 42);
		contentPane.add(btnNewButton);
		
		

		//BOTOES CENARIOS ___________________________________________________________________________________________________________________________________________________________________________

		
		String[] paths = {
			    "",
			    "/imagens/barbaro.jpg",
			    "/imagens/mago.jpg",
			    "/imagens/cavaleiro.jpg",
			    "/imagens/pelado.jpg"
			};
		
		int btnW     = 48;
		int btnH     = 50;
		
//----------------------------------------------BOTÕES CENARIO IRITHYLL---------------------------------------------------------------------------------------------------------------------------------------------------
		int btnCount = 5;
		int startX   = 450;
		int startY   = 535;

		for (int i = 0; i < btnCount; i++) {
		    JButton btn = new JButton("");
		    int x = startX + i * 55; 
		    btn.setBounds(x, startY, btnW, btnH);
		    contentPane.add(btn);
		    
		    btn.addActionListener(e -> {
		    	
		    	
		        if (personagem != 0) {
		            JanelaBoss pergunta = new JanelaBoss();
		            pergunta.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		            pergunta.setLocationRelativeTo(Mapa.this);
		            pergunta.setVisible(true);
		        }
		        String path = paths[personagem];
		        btn.setIcon(path.isEmpty()
		            ? null
		            : new ImageIcon(Mapa.class.getResource(path)));
		    });
		}
//		JButton btnIrithyllButton = new JButton("");
//		btnIrithyllButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				
//				
//				if (personagem != 0) {
//					
//					
//			    Janela pergunta = new Janela();
//			    pergunta.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//			    pergunta.setLocationRelativeTo(Mapa.this); // centra em cima do mapa
//			    pergunta.setVisible(true);
//				if(personagem == 1) 
//					btnIrithyllButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnIrithyllButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnIrithyllButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnIrithyllButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				
//				}
//				else if(personagem == 0)
//					btnIrithyllButton.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnIrithyllButton.setBounds(161, 269, 24, 23);
//		contentPane.add(btnIrithyllButton);
//
//		JButton btnIrithyllButton2 = new JButton("");
//		btnIrithyllButton2.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if (personagem != 0) {
//					
//					
//				    Janela pergunta = new Janela();
//				    pergunta.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//				    pergunta.setLocationRelativeTo(Mapa.this); // centra em cima do mapa
//				    pergunta.setVisible(true);
//				if(personagem == 1) 
//					btnIrithyllButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnIrithyllButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnIrithyllButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnIrithyllButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnIrithyllButton2.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		}
//			
//		});
//		btnIrithyllButton2.setBounds(191, 269, 24, 23);
//		contentPane.add(btnIrithyllButton2);
//
//		JButton btnIrithyllButton3 = new JButton("");
//		btnIrithyllButton3.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				
//				
//				if (personagem != 0) {
//					
//					
//				    Janela pergunta = new Janela();
//				    pergunta.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//				    pergunta.setLocationRelativeTo(Mapa.this); // centra em cima do mapa
//				    pergunta.setVisible(true);
//				
//				if(personagem == 1) 
//					btnIrithyllButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnIrithyllButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnIrithyllButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnIrithyllButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnIrithyllButton3.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}}
//		});
//		btnIrithyllButton3.setBounds(221, 269, 24, 23);
//		contentPane.add(btnIrithyllButton3);
//
//		JButton btnIrithyllButton4 = new JButton("");
//		btnIrithyllButton4.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnIrithyllButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnIrithyllButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnIrithyllButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnIrithyllButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnIrithyllButton4.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnIrithyllButton4.setBounds(251, 269, 24, 23);
//		contentPane.add(btnIrithyllButton4);
//
//		JButton btnIrithyllButton5 = new JButton("");
//		btnIrithyllButton5.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnIrithyllButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnIrithyllButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnIrithyllButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnIrithyllButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnIrithyllButton5.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnIrithyllButton5.setBounds(281, 269, 24, 23);
//		contentPane.add(btnIrithyllButton5);
		
		

		
//----------------------------------------------BOTÕES CENARIO FARRON---------------------------------------------------------------------------------------------------------------------------------------------------

		int farronCount = 5;
		int farronStartX = 875;
		int farronY = 640;



		for (int i = 0; i < farronCount; i++) {
		    JButton btn = new JButton();
		    btn.setBounds(farronStartX + i * 55, farronY, btnW, btnH);
		    contentPane.add(btn);

		    btn.addActionListener(e -> {
		        if (personagem != 0) {
		            Janela pergunta = new Janela();
		            pergunta.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		            pergunta.setLocationRelativeTo(Mapa.this);
		            pergunta.setVisible(true);
		        }
		        String path = paths[personagem];
		        btn.setIcon(path.isEmpty()
		            ? null
		            : new ImageIcon(Mapa.class.getResource(path)));
		    });
		}
//		JButton btnFarronButton = new JButton("");
//		btnFarronButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnFarronButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnFarronButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnFarronButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnFarronButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnFarronButton.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnFarronButton.setBounds(406, 324, 24, 23);
//		contentPane.add(btnFarronButton);
//		
//		JButton btnFarronButton2 = new JButton("");
//		btnFarronButton2.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnFarronButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnFarronButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnFarronButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnFarronButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnFarronButton2.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnFarronButton2.setBounds(436, 324, 24, 23);
//		contentPane.add(btnFarronButton2);
//		
//		JButton btnFarronButton3 = new JButton("");
//		btnFarronButton3.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnFarronButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnFarronButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnFarronButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnFarronButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnFarronButton3.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnFarronButton3.setBounds(466, 324, 24, 23);
//		contentPane.add(btnFarronButton3);
//		
//		JButton btnFarronButton4 = new JButton("");
//		btnFarronButton4.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnFarronButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnFarronButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnFarronButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnFarronButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnFarronButton4.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnFarronButton4.setBounds(496, 324, 24, 23);
//		contentPane.add(btnFarronButton4);
//		
//		JButton btnFarronButton5 = new JButton("");
//		btnFarronButton5.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnFarronButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnFarronButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnFarronButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnFarronButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnFarronButton5.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnFarronButton5.setBounds(526, 324, 24, 23);
//		contentPane.add(btnFarronButton5);
		

//----------------------------------------------BOTÕES CENARIO LOTHRIC---------------------------------------------------------------------------------------------------------------------------------------------------

		int lothricCount  = 5;
		int lothricStartX = 620;
		int lothricY      = 240;
		for (int i = 0; i < lothricCount; i++) {
		    JButton btn = new JButton();
		    btn.setBounds(lothricStartX + i * 55, lothricY, btnW, btnH);
		    contentPane.add(btn);
		    btn.addActionListener(e -> {
		        if (personagem != 0) {
		            Janela pergunta = new Janela();
		            pergunta.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		            pergunta.setLocationRelativeTo(Mapa.this);
		            pergunta.setVisible(true);
		        }
		        String path = paths[personagem];
		        btn.setIcon(path.isEmpty()
		            ? null
		            : new ImageIcon(Mapa.class.getResource(path)));
		    });
		}


//----------------------------------------------BOTÕES CENARIO ROAD OF SACRIFICES---------------------------------------------------------------------------------------------------------------------------------------------------

		int roadCount  = 5;
		int roadStartX = 1290;
		int roadY      = 530;
		for (int i = 0; i < roadCount; i++) {
		    JButton btn = new JButton();
		    btn.setBounds(roadStartX + i * 55, roadY, btnW, btnH);
		    contentPane.add(btn);
		    btn.addActionListener(e -> {
		        if (personagem != 0) {
		            Janela pergunta = new Janela();
		            pergunta.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		            pergunta.setLocationRelativeTo(Mapa.this);
		            pergunta.setVisible(true);
		        }
		        String path = paths[personagem];
		        btn.setIcon(path.isEmpty()
		            ? null
		            : new ImageIcon(Mapa.class.getResource(path)));
		    });
		}
//		JButton btnLothricButton = new JButton("");
//		btnLothricButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnLothricButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnLothricButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnLothricButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnLothricButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnLothricButton.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnLothricButton.setBounds(251, 95, 24, 23);
//		contentPane.add(btnLothricButton);
//		
//		JButton btnLothricButton2 = new JButton("");
//		btnLothricButton2.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnLothricButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnLothricButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnLothricButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnLothricButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnLothricButton2.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnLothricButton2.setBounds(281, 95, 24, 23);
//		contentPane.add(btnLothricButton2);
//		
//		JButton btnLothricButton3 = new JButton("");
//		btnLothricButton3.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnLothricButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnLothricButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnLothricButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnLothricButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnLothricButton3.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnLothricButton3.setBounds(311, 95, 24, 23);
//		contentPane.add(btnLothricButton3);
//		
//		JButton btnLothricButton4 = new JButton("");
//		btnLothricButton4.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnLothricButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnLothricButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnLothricButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnLothricButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnLothricButton4.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnLothricButton4.setBounds(341, 95, 24, 23);
//		contentPane.add(btnLothricButton4);
//		
//		JButton btnLothricButton5 = new JButton("");
//		btnLothricButton5.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnLothricButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnLothricButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnLothricButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnLothricButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnLothricButton5.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnLothricButton5.setBounds(371, 95, 24, 23);
//		contentPane.add(btnLothricButton5);
//		
//		JButton btnRoadButton = new JButton("");
//		btnRoadButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnRoadButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnRoadButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnRoadButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnRoadButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnRoadButton.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnRoadButton.setBounds(652, 269, 24, 23);
//		contentPane.add(btnRoadButton);
//		
//		JButton btnRoadButton2 = new JButton("");
//		btnRoadButton2.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnRoadButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnRoadButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnRoadButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnRoadButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnRoadButton2.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnRoadButton2.setBounds(682, 269, 24, 23);
//		contentPane.add(btnRoadButton2);
//		
//		JButton btnRoadButton3 = new JButton("");
//		btnRoadButton3.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnRoadButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnRoadButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnRoadButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnRoadButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnRoadButton3.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnRoadButton3.setBounds(712, 269, 24, 23);
//		contentPane.add(btnRoadButton3);
//		
//		JButton btnRoadButton4 = new JButton("");
//		btnRoadButton4.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnRoadButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnRoadButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnRoadButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnRoadButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnRoadButton4.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnRoadButton4.setBounds(742, 269, 24, 23);
//		contentPane.add(btnRoadButton4);
//		
//		JButton btnRoadButton5 = new JButton("");
//		btnRoadButton5.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnRoadButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnRoadButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnRoadButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnRoadButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnRoadButton5.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnRoadButton5.setBounds(772, 269, 24, 23);
//		contentPane.add(btnRoadButton5);
		

//----------------------------------------------BOTÕES CENARIO CATEDRAL---------------------------------------------------------------------------------------------------------------------------------------------------

		
		int catedralCount  = 5;
		int catedralStartX = 1310;
		int catedralY      = 370;
		for (int i = 0; i < catedralCount; i++) {
		    JButton btn = new JButton();
		    btn.setBounds(catedralStartX + i * 55, catedralY, btnW, btnH);
		    contentPane.add(btn);

		    btn.addActionListener(e -> {
		        if (personagem != 0) {
		            Janela pergunta = new Janela();
		            pergunta.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		            pergunta.setLocationRelativeTo(Mapa.this);
		            pergunta.setVisible(true);
		        }
		        String path = paths[personagem];
		        btn.setIcon(path.isEmpty()
		            ? null
		            : new ImageIcon(Mapa.class.getResource(path)));
		    });
		}


//		JButton btnCatedralButton = new JButton("");
//		btnCatedralButton.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnCatedralButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnCatedralButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnCatedralButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnCatedralButton.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnCatedralButton.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnCatedralButton.setBounds(652, 182, 24, 23);
//		contentPane.add(btnCatedralButton);
//		
//		JButton btnCatedralButton2 = new JButton("");
//		btnCatedralButton2.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnCatedralButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnCatedralButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnCatedralButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnCatedralButton2.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnCatedralButton2.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnCatedralButton2.setBounds(682, 182, 24, 23);
//		contentPane.add(btnCatedralButton2);
//
//		JButton btnCatedralButton3 = new JButton("");
//		btnCatedralButton3.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnCatedralButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnCatedralButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnCatedralButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnCatedralButton3.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnCatedralButton3.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnCatedralButton3.setBounds(712, 182, 24, 23);
//		contentPane.add(btnCatedralButton3);
//		
//		JButton btnCatedralButton4 = new JButton("");
//		btnCatedralButton4.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnCatedralButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnCatedralButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnCatedralButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnCatedralButton4.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnCatedralButton4.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnCatedralButton4.setBounds(742, 182, 24, 23);
//		contentPane.add(btnCatedralButton4);
//		
//		JButton btnCatedralButton5 = new JButton("");
//		btnCatedralButton5.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if(personagem == 1) 
//					btnCatedralButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
//				else if(personagem == 2)
//					btnCatedralButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mago.jpg")));
//				else if(personagem == 3)
//					btnCatedralButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/cavaleiro.jpg")));
//				else if (personagem == 4)
//					btnCatedralButton5.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/pelado.jpg")));
//				else if(personagem == 0)
//					btnCatedralButton5.setIcon(new ImageIcon(Mapa.class.getResource("")));
//			}
//		});
//		btnCatedralButton5.setBounds(772, 182, 24, 23);
//		contentPane.add(btnCatedralButton5);
//		
		//--------------------------------------------- ETIQUETAS DE CENARIO ---------------------------------------------------------------------------------------------------------------------------------------------------

		
		JLabel lblLothric = new JLabel("Lothric",SwingConstants.CENTER);
		lblLothric.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblLothric.setOpaque(true);
		lblLothric.setBackground(Color.BLACK);
		lblLothric.setForeground(Color.WHITE);
		lblLothric.setBounds(680, 193, 147, 33);
		lblLothric.setBorder(new LineBorder(Color.WHITE, 2, true));
		contentPane.add(lblLothric);
		
		JLabel lblIrythill = new JLabel("Irithyll of The Boreal Valley", SwingConstants.CENTER);
		lblIrythill.setOpaque(true);
		lblIrythill.setForeground(Color.WHITE);
		lblIrythill.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblIrythill.setBorder(new LineBorder(Color.WHITE, 2, true));
		lblIrythill.setBackground(Color.BLACK);
		lblIrythill.setBounds(394, 488, 364, 33);
		contentPane.add(lblIrythill);
		
		JLabel lblFarron = new JLabel("Farron Keep", SwingConstants.CENTER);
		lblFarron.setOpaque(true);
		lblFarron.setForeground(Color.WHITE);
		lblFarron.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblFarron.setBorder(new LineBorder(Color.WHITE, 2, true));
		lblFarron.setBackground(Color.BLACK);
		lblFarron.setBounds(923, 597, 180, 33);
		contentPane.add(lblFarron);
		
		JLabel lblRoad = new JLabel("Road of Sacrifices", SwingConstants.CENTER);
		lblRoad.setOpaque(true);
		lblRoad.setForeground(Color.WHITE);
		lblRoad.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblRoad.setBorder(new LineBorder(Color.WHITE, 2, true));
		lblRoad.setBackground(Color.BLACK);
		lblRoad.setBounds(1302, 488, 236, 33);
		contentPane.add(lblRoad);
		
		JLabel lblCatedral = new JLabel("Catedral of the Deep", SwingConstants.CENTER);
		lblCatedral.setOpaque(true);
		lblCatedral.setForeground(Color.WHITE);
		lblCatedral.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblCatedral.setBorder(new LineBorder(Color.WHITE, 2, true));
		lblCatedral.setBackground(Color.BLACK);
		lblCatedral.setBounds(1304, 329, 277, 33);
		contentPane.add(lblCatedral);
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/mapaV4.png")));
		lblNewLabel.setBounds(0, 0, 1900, 940);
		contentPane.add(lblNewLabel);
		
		
		

		
	}
}
