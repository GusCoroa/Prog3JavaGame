package view;

import java.awt.BorderLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class JanelaBoss extends JFrame {
    private JPanel contentPane;
    private JLabel perguntaLabel;
    private JTextField respostaField;
    private JButton enviarButton;
    private Connection con;

    public JanelaBoss() {
        super("Pergunta");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1200, 750);
        setLocationRelativeTo(null);

        contentPane = new JPanel(new BorderLayout(10, 10));
        setContentPane(contentPane);

        conectar();
        Pergunta p = carregarPerguntaAleatoria();

        perguntaLabel = new JLabel("<html><body style='width:350px;'>"
                + p.texto
                + "</body></html>");
        perguntaLabel.setFont(perguntaLabel.getFont().deriveFont(24f));
        contentPane.add(perguntaLabel, BorderLayout.NORTH);

        JLabel lblNewLabel = new JLabel("");
    	lblNewLabel.setIcon(new ImageIcon(Mapa.class.getResource("/imagens/barbaro.jpg")));
    	lblNewLabel.setBounds(0, 0, 40, 40);
    	contentPane.add(lblNewLabel);
        // Campo de texto para a resposta do usuário
        JPanel painelResposta = new JPanel(new BorderLayout(5, 5));
        JLabel lblResposta = new JLabel("Sua resposta:");
        lblResposta.setFont(lblResposta.getFont().deriveFont(18f));
        respostaField = new JTextField();

        painelResposta.add(lblResposta, BorderLayout.NORTH);
        painelResposta.add(respostaField, BorderLayout.CENTER);
        contentPane.add(painelResposta, BorderLayout.CENTER);

        enviarButton = new JButton("Enviar");
        enviarButton.addActionListener(e -> {
            String resposta = respostaField.getText().trim();
            String msg;
            if (resposta.equalsIgnoreCase(p.correta)) {
                msg = "Correto!";
            } else {
                msg = "Errado! A resposta correta é: " + p.correta;
            }
            JOptionPane.showMessageDialog(this, msg);
            dispose();
        });
        contentPane.add(enviarButton, BorderLayout.SOUTH);
        
    }

    private void conectar() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/perguntas?useSSL=false&serverTimezone=UTC",
                "root", ""
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Pergunta carregarPerguntaAleatoria() {
        Pergunta p = new Pergunta();
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, texto FROM perguntas ORDER BY RAND() LIMIT 1")) {
            if (rs.next()) {
                int id = rs.getInt("id");
                p.texto = rs.getString("texto");

                try (PreparedStatement pc = con.prepareStatement(
                         "SELECT resposta FROM respostas_certas WHERE pergunta_id = ?"
                     )) {
                    pc.setInt(1, id);
                    try (ResultSet rcor = pc.executeQuery()) {
                        if (rcor.next()) p.correta = rcor.getString("resposta");
                    }
                }

                List<String> lista = new ArrayList<>();
                lista.add(p.correta);
                try (PreparedStatement pe = con.prepareStatement(
                         "SELECT resposta FROM respostas_erradas WHERE pergunta_id = ? ORDER BY RAND() LIMIT 3"
                     )) {
                    pe.setInt(1, id);
                    try (ResultSet rer = pe.executeQuery()) {
                        while (rer.next()) lista.add(rer.getString("resposta"));
                    }
                }

                Collections.shuffle(lista);
                p.opcoes = lista.toArray(new String[0]);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }

    private static class Pergunta {
        String texto;
        String correta;
        String[] opcoes;
    }
    

}
